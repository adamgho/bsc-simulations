source('tools/methods.R')
source('tools/data_tools.R')
source('tools/DAG_tools.R')
library(InvariantCausalPrediction)
## datfiles <- c('localdata/singletargets_10_1_30_100_sdw7_sdh5/1.rds',
              'data/small_and_wrong/singletargets_10_5000_30_100_sdw7_sdh5/2.rds')
## DAG_list <- readRDS(datfiles[2])
## DAG <- DAG_list[[1]]
DAG <- get_random_DAG(5, 5)
plot(DAG)
intersect(DAG$anc_y, DAG$x)
intersect(DAG$pa_y, DAG$x)
DAG <- sim_singletargets(DAG, 10, 1, 3, 10, 7, 5)
DAG$dat$setting
dat <- DAG$dat
i <- ICP(dat$X, as.vector(dat$Y), dat$setting)
p_values_OLS(dat)
p_values_POLS(dat)
p_values_DPOLS(dat)
