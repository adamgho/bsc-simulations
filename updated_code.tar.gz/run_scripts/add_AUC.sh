#!/bin/bash

Rscript run_scripts/alltargets_AUC.R
Rscript run_scripts/singletargets_AUC.R
