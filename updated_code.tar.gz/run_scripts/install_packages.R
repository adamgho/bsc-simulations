# Installs the required R packages

install.packages("MASS")
install.packages("Matrix")
install.packages("tidyverse")
install.packages("igraph")
install.packages("InvariantCausalPrediction")

