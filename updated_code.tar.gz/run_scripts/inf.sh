#!/bin/bash

for FILE in $(ls *.R); do
	sed -Ei 's/((-coef|-pvals|"ICP))/\1"/' $FILE
done
