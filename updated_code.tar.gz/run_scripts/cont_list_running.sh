#!/bin/bash

watch -n 1 -t ./run_scripts/list_running.sh
