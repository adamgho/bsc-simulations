source("tools/AUC_tools.R")

# Adds tpr_fpr for OLS (both based on size of coefficients and p-values)

params <- as.numeric(commandArgs(trailingOnly = TRUE))
dir <- sprintf("data/alltargets_%d_%d_sdw%d_sdh%d",
                    params[1], params[2], params[3], params[4])

if (!file.exists(str_c(dir, "/tpr_fpr_OLS-coef.R"))) {
    save_tpr_fpr(dir, beta_OLS, "OLS-coef",
                    n_DAGs_to_process = 1000)
}