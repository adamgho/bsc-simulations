#!/bin/bash

for i in 1 2 3 4; do
	Rscript run_scripts/alltargets_data.R $i > .output_all_$i.txt &
done
wait
sh ./run_scripts/alltargets_tpr_fpr.sh
