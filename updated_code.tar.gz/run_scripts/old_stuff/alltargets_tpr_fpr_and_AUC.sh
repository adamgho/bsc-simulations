#!/bin/bash

# Generates tpr_fpr files, ROC_points files, and AUC files.

Rscript run_scripts/alltargets_OLS.R
Rscript run_scripts/alltargets_POLS.R
Rscript run_scripts/alltargets_DPOLS.R
Rscript run_scripts/alltargets_ICP.R
Rscript run_scripts/alltargets_AUC.R
