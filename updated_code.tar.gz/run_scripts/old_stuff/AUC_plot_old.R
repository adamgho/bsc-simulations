library(tidyverse)
theme_set(
  theme_bw(base_size=12, base_family="Palatino") %+replace%
  theme(
    panel.grid = element_blank(),
    axis.ticks = element_line(size = 0.3),
    panel.border = element_blank(),
    axis.line = element_line(size = 0.3),
    panel.background = element_rect(fill = "transparent",colour = NA),
    plot.background = element_rect(fill = "transparent",colour = NA),
    legend.background = element_rect(fill="transparent", colour=NA),
    legend.key        = element_rect(fill="transparent", colour=NA),
    strip.background = element_rect(fill = "transparent",colour = NA)
  )
)
update_geom_defaults("point", list(size = 0.5))
update_geom_defaults("smooth", list(size = 0.3, col = 4))
update_geom_defaults("abline", list(size = 0.3))
update_geom_defaults("line", list(size = 0.3))

setwd("~/Documents/projects/bachelorprojekt/thesis/figures")

AUC_tib <- tibble(readRDS("data/AUC_alltargets.rds"))

AUC_tib <- tibble(readRDS("/media/veracrypt1/data/alltargets_AUC.rds"))



AUC_tib %>% 
    pivot_wider(names_from = measure,
                names_prefix = "AUC_",
                values_from = AUC) %>% 
    filter(shift_noise_sd == 7,
            n_obs_each == 2,
            sd_hiddens == 5) %>%
    ggplot(aes(x = num_interv, y = AUC_mean)) +
    geom_point(aes(col = method)) +
    geom_line(aes(col = method)) +
    facet_grid(sd_hiddens ~ type) +
    labs(
        title = "alltargets. Obs. per env.: 2. Intervention sd: 7. Hiddens sd: 5.",
        x = "Number of environments",
        y = "AUC"
    )

AUC_tib %>% 
    pivot_wider(names_from = measure,
                names_prefix = "AUC_",
                values_from = AUC) %>% 
    filter(shift_noise_sd == 7,
            n_obs_each == 2) %>%
    ggplot(aes(x = num_interv, y = AUC_mean)) +
    geom_point(aes(col = method)) +
    geom_line(aes(col = method)) +
    facet_wrap(~ type) +
    labs(
        title = "alltargets. Obs. per env.: 2. Intervention sd: 7.",
        x = "Number of environments",
        y = "AUC"
    ) +
    scale_color_manual(labels = c("OLS", "POLS", "DPOLS"),
                        values = 2:4)

ggsave("alltargets_2_x_sd7.png")

AUC_tib %>% 
    pivot_wider(names_from = measure,
                names_prefix = "AUC_",
                values_from = AUC) %>% 
    filter(shift_noise_sd == 7,
            n_obs_each == 10) %>%
    ggplot(aes(x = num_interv, y = AUC_mean)) +
    geom_point(aes(col = method)) +
    geom_line(aes(col = method)) +
    facet_wrap(~ type) +
    labs(
        title = "alltargets. Obs. per env.: 10. Intervention sd: 7.",
        x = "Number of environments",
        y = "AUC"
    ) +
    scale_color_manual(labels = c("OLS", "POLS", "DPOLS"),
                        values = 2:4)

ggsave("alltargets_10_x_sd7.png")

AUC_tib %>% 
    pivot_wider(names_from = measure,
                names_prefix = "AUC_",
                values_from = AUC) %>% 
    filter(shift_noise_sd == 7,
            num_interv == 100) %>%
    ggplot(aes(x = n_obs_each, y = AUC_mean)) +
    geom_point(aes(col = method)) +
    geom_line(aes(col = method)) +
    facet_wrap(~ type) +
    labs(
        title = "alltargets. Num. of env.: 100. Intervention sd: 7.",
        x = "Number of observations per environment",
        y = "AUC"
    ) +
    scale_color_manual(labels = c("OLS", "POLS", "DPOLS"),
                        values = 2:4)

ggsave("alltargets_x_100_sd7.png")

AUC_tib %>% 
    pivot_wider(names_from = measure,
                names_prefix = "AUC_",
                values_from = AUC) %>% 
    filter(shift_noise_sd == 7,
            num_interv == 500) %>%
    ggplot(aes(x = n_obs_each, y = AUC_mean)) +
    geom_point(aes(col = method)) +
    geom_line(aes(col = method)) +
    facet_wrap(~ type) +
    labs(
        title = "alltargets. Num. of env.: 500. Intervention sd: 7.",
        x = "Number of observations per environment",
        y = "AUC"
    ) +
    scale_color_manual(labels = c("OLS", "POLS", "DPOLS"),
                        values = 2:4)

ggsave("alltargets_x_500_sd7.png")

AUC_tib %>% 
    pivot_wider(names_from = measure,
                names_prefix = "AUC_",
                values_from = AUC) %>% 
    filter(n_obs_each == 2,
            num_interv == 500) %>%
    ggplot(aes(x = shift_noise_sd, y = AUC_mean)) +
    geom_point(aes(col = method)) +
    geom_line(aes(col = method)) +
    facet_wrap(~ type) +
    labs(
        title = "alltargets. Num. of env.: 500. Obs. per env.: 2.",
        x = "Intervention sd",
        y = "AUC"
    ) +
    scale_color_manual(labels = c("OLS", "POLS", "DPOLS"),
                        values = 2:4)

ggsave("alltargets_2_500_sdx.png")

AUC_tib %>% 
    pivot_wider(names_from = measure,
                names_prefix = "AUC_",
                values_from = AUC) %>% 
    filter(n_obs_each == 10,
            num_interv == 500) %>%
    ggplot(aes(x = shift_noise_sd, y = AUC_mean)) +
    geom_point(aes(col = method)) +
    geom_line(aes(col = method)) +
    facet_wrap(~ type) +
    labs(
        title = "alltargets. Num. of env.: 500. Obs. per env.: 10.",
        x = "Intervention sd",
        y = "AUC"
    ) +
    scale_color_manual(labels = c("OLS", "POLS", "DPOLS"),
                        values = 2:4)

ggsave("alltargets_10_500_sdx.png")

# Consider including a few well chosen ROC curves in the thesis?

ROC_tib <- tibble(readRDS(
    "/media/veracrypt1/data/alltargets_2_4000_sd7/ROC_points.rds"))

ggplot(ROC_tib, aes(x = fpr_anc_mean, y = tpr_anc_mean, col = method)) +
    geom_point() +
    geom_line() +
    geom_abline() +
    coord_fixed()
