#!/bin/bash

# Generates tpr_fpr files, ROC_points files, and AUC files.

Rscript run_scripts/singletargets_OLS.R
Rscript run_scripts/singletargets_POLS.R
Rscript run_scripts/singletargets_DPOLS.R
Rscript run_scripts/singletargets_ICP.R
Rscript run_scripts/singletargets_AUC.R
