# Fjern denne fil før du uploader.
# Den er bare til at teste ting med!

source("tools/DAG_tools.R")

DAG_list <- list()
n_DAGs <- 5

for (i in 1:n_DAGs) {
  if (i %% 50 == 0) print(i)
  DAG_list <- c(DAG_list, list(get_random_DAG(n_x = 30,
                                                 n_h = 30,
                                                 prob_connect = 0.4)))
}

source("tools/data_tools.R")

sim_alltargets_grid(DAG_list,
                    c(2,10), c(25, 50),
                    c(7, 14), c(5, 10))

dat_list <- readRDS("data/alltargets_10_25_sdw14_sdh10/1.rds")
dat_list[[1]]$dat

source("tools/AUC_tools.R")

save_tpr_fpr("data/alltargets_10_25_sdw14_sdh10",
            get_DPOLS, "DPOLS", n_DAGs_total = 5)

tib1 <- tibble(readRDS("data/alltargets_10_25_sdw14_sdh10/tpr_fpr_DPOLS.rds"))

tib1
tib1 %>% group_by(n_select, method) %>% summarise(across(.fns = mean)) %>% tail
save_tpr_fpr("data/alltargets_10_25_sdw14_sdh10",
            p_values_ICP, "IC", n_DAGs_total = 5)

tib2 <- tibble(readRDS("data/alltargets_10_25_sdw14_sdh10/tpr_fpr_IC.rds"))

tib
tib2 %>% group_by(n_select, method) %>% summarise(across(.fns = mean)) %>% head

add_missing_tpr_fpr(p_values_ICP, "IC", n_DAGs_total = 5)
sim_type <- "alltargets"
list.files("data/alltargets_2_50_sdw7_sdh5", pattern = "tpr_fpr_")

save_ROC_points("data/alltargets_10_25_sdw14_sdh10")

tib <- readRDS("data/alltargets_10_25_sdw14_sdh10/ROC_points.rds")
tib <- tibble(tib)
tail(tib)

add_missing_ROC_points()

add_missing_AUC()

collect_AUC()

mat <- matrix(scan("run_scripts/alltargets1.txt", skip = 1),
                ncol = 4, byrow = T)

source("tools/data_tools.R")

DAG_data <- sim_singletargets(DAG_list[[1]],
                  5,
                  2,
                  10,
                  15,
                  7,
                  5)

DAG_data$dat$setting
DAG_data$dat$interv

sim_singletargets_datasets(DAG_list,
5,2,10,15,7,5)

DAG_data <- readRDS("data/singletargets_5_2_10_15_sdw7_sdh5/1.rds")

DAG_data <- readRDS("data/singletargets_10_1_15_100_sdw7_sdh5/1.rds")

length(DAG_data[[1]]$dat$setting)
length(DAG_data[[1]]$dat$Y)

DAG_list <- readRDS("data/singletargets_10_50_15_100_sdw7_sdh5/1.rds")
DAG_list[[1]]
DAG_list[[1]]$dat$Y


