source("run_scripts/tpr_fpr_cli.R")

save_tpr_fpr_cli_args(beta_OLS, "OLS-coef")